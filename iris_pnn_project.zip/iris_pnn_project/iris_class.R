library(pnn)
library(class)
library(genoud)
library(rgenoud)

set.seed(1)

data(norms, package = "pnn")

norms[1:10, ]

data.raw <- iris
data.new <- subset(data.raw, select = c(5,1,2,3,4))
iris #This dataset is already present. 
pnn <- learn(data.new)
pnn$model #Probabilistic neural network

pnn$set[1:150, ] #set training set to 150 observations 

pnn$categories

pnn$k #4 variables

pnn$n #150 total observations

pnn <- smooth(pnn)
pnn$sigma #0.584197

guess(pnn, c(5.6, 3.9, 2.7, 2.5)) #enter your own input and guess
guess(pnn, c(5.6, 3.9, 2.7, 2.5))$category




perf(pnn) #To check performance over entire data set
#fails=5; success_rate=0.967; success=145
predicted <- perf(pnn)$guessed
data.new = cbind(data.new, predicted)

data.new$hits <- NULL
data.new$Sp <- NULL
data.new$Pr <- NULL

Sp = 1:150
Oneto150 = 1:150
for(i in Oneto150){
 Sp[i] = 0
}

Pr = 1:150
Oneto150 = 1:150
for(i in Oneto150){
  Pr[i] = 0
}

hits = 1:150
Oneto150 = 1:150
for(i in Oneto150){
  hits[i] = 0
}
 

data.new = cbind(data.new, hits)
data.new = cbind(data.new, Sp)
data.new = cbind(data.new, Pr)

for(i in Oneto150){

if( data.new$Species[i] == 'setosa'){
  data.new$Sp[i] = 1
} else if(data.new$Species[i] == 'versicolor'){
  data.new$Sp[i] = 2
} else {
  data.new$Sp[i] = 3
}}

for(i in Oneto150){
  
  if( data.new$predicted[i] == 'setosa'){
    data.new$Pr[i] = 1
  } else if(data.new$predicted[i] == 'versicolor'){
    data.new$Pr[i] = 2
  } else {
    data.new$Pr[i] = 3
  }}

for(i in Oneto150){
  
  if( data.new$Sp[i] == data.new$Pr[i]){
    data.new$hits[i] = 0
  }  else {
    data.new$hits[i] = 1
  }}

sum_hits = sum(data.new$hits==0)
hit_ratio = sum_hits/length(data.new$hits)
#0.9666667



#y = 1:len(data.new)
#for (i in y) {
#if(data.new$Species == "setosa" && data.new$predicted != "setosa"){
#  data.new$hits = 0
#} else if(data.new$Species == "versicolor" && data.new$predicted != "versicolor"){
#  data.new$hits = 0
#} else if(data.new$Species == "virginica" && data.new$predicted != "virginica"){
#  data.new$hits = 0
#} else {
#  data.new$hits = 1
#}
#}


   


